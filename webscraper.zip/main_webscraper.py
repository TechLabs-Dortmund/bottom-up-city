from bs4 import BeautifulSoup
import requests
from selenium import webdriver

#webscraper for listing sites
response = requests.get("https://e-tankstellen-finder.com/at/de/elektrotankstellen?open=list&search=Dortmund,%20Nordrhein-Westfalen,%20Deutschland")
data = response.content
soup = BeautifulSoup(data, "html.parser")

all_names_elements = soup.find(id="search-results") #prints none-type aus
print(all_names_elements)
job_elements = all_names_elements.find_all("div", class_="list-group-item")
for job_element in job_elements:                    #non-type non iterable?
    title_element = job_element.find("h5", class_="panel-header")
    location_element = job_element.find("a").getText()
    print(title_element)
    print(location_element)



#Selenium und Google form
#chrome_driver_path = r"C:\Users\saqib\Desktop\chromedriver\chromedriver.exe"
#driver = webdriver.Chrome(executable_path=chrome_driver_path)
#driver.maximize_window()
#driver.implicitly_wait(20)
#url = "https://e-tankstellen-finder.com/at/de/elektrotankstellen?open=list&search=Dortmund,%20Nordrhein-Westfalen,%20Deutschland"
#driver.get(url)


#name = driver.find_element_by_xpath('//*[@id="search-results"]/div[2]/span/h5/a')
#print(name)
